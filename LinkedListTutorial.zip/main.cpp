//credit to Derek Banas for his tutorial on how to implement a linked list data structure https://www.youtube.com/watch?v=KJWOm1bXUxM
#include <iostream>
//including the data strutures needed to implement singly and doubly linked lists
#include <forward_list>
#include <list>

//'forward_list' and 'list' are included in the std namespace so 'using namespace std' or 'std::' are vital to using linked lists
using namespace std;

int main()
{
	//creating a singly linked list to store type 'int' variables
	forward_list<int> SLLint{34, 56, 78};

	//printing off the elements of the singly linked list
	for (int i : SLLint)
	{
		cout << i << endl;
	}

	//pushing the number 48 to the start of the list
	SLLint.push_front(48);

	//puahing the number 2 to the start of the list
	SLLint.emplace_after(SLLint.begin(), 2);

	//popping off the first element in the list
	SLLint.pop_front();

	//sorting the list for least to greatest
	SLLint.sort();

	cout << endl;

	//printing off the elements of the singly linked list again
	for (int i : SLLint)
	{
		cout << i << endl;
	}

	//making an array to add to the list
	int arr[4] = { 2, 4, 6, 7 };

	//inserting the elements of the array after the first node
	SLLint.insert_after(SLLint.begin(), arr, arr + 4);

	//this deletes any duplicate numbers in the list
	SLLint.unique();

	//this reverses the order of the list
	SLLint.reverse();

	//this removes any node with the value 7 from the list
	SLLint.remove(7);

	cout << endl;

	//printing off the elements of the singly linked list again
	for (int i : SLLint)
	{
		cout << i << endl;
	}

	//creating a Doubly Linked List of chars
	list<char> DLLchar{ 'a','b','c' };

	//pushes the letter 'd' to the back of the list
	DLLchar.push_back('d');
	//pushes the letter 'z' to the front of the list
	DLLchar.push_front('z');

	//removes the first node from the list
	DLLchar.pop_front();
	//removes the last node from the list
	DLLchar.pop_back();

	//inserts the letter 'x' at the named point in the list
	DLLchar.insert(DLLchar.begin(), 'x');

	//sorting the list
	DLLchar.sort();

	//creating a char array to add to the list
	char arr2[5] = { 'x','y','z','w', 'q' };

	//inserting the array at teh end of the list
	DLLchar.insert(DLLchar.end(), arr2, arr2 + 5);

	//getting rid of any duplicate nodes
	DLLchar.unique();

	//reverses the order of the list
	DLLchar.reverse();

	cout << endl;

	//printing off the elements of the doubly linked list
	for (char i : DLLchar)
	{
		cout << i << endl;
	}

	return 0;
}